<?php 
    include("../inc/database.php");

    $name = $_POST['name'];
    /* $username = $_POST['username'];
    $password = md5($_POST['password']);
    $access_level = $_POST['access_level']; */

    foreach ($name as $x => $val) {
        echo $name = $val;
        echo $username = ($_POST['username'][$x]);
        echo $password = md5($_POST['password'][$x]);
        echo $access_level = ($_POST['access_level'][$x]);
    }

    //create array for data dump
    $userArray[] = "('$name','$username','$password','$access_level')";

    //run insert into sql
    $sql="INSERT INTO user(user_name, u_username, u_password, u_access_lvl)
    VALUES" . implode("', '", $userArray); 

    //if sql statement no error
    if($conn->query($sql))
    {
        //redirect to user page
        header("Location:user_info.php");
    }
    else
    {
        //if theres error
        die("SQL error report ".$conn->error);

    }
?>