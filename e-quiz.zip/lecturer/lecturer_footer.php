<br>
        <!-- FOOTER -->
        <footer id="sticky-footer" class="flex-shrink-0 py-4 bg-dark text-white-50">
            <div class="container text-center">
            <small>E-QUIZ</small><br>
            </div>
        </footer>
    </body>
</html>

<style>
    /* Sticky Footer Classes */
    html, body {
    height: 100%;
    }

    #page-content {
    flex: 1 0 auto;
    }

    /* Other Classes for Page Styling */

    body {
    background: linear-gradient(to left,   #68646a ,   #7181dd
 );
    }
</style>