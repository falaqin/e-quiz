<?php
include("std_header.php");
include('../inc/database.php');
?>

<div class="container">
    
</div>

<?php
include("std_footer.php");
?>