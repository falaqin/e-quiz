<!DOCTYPE html>
<html lang="en">
    <?php
    include('std_header.php');
    ?>

 <br><br>
 <div class="container">
     <div class="row">
         <div class="col-md-12">
             
             
             <div class="panel title">
                     <table class="table table-striped title1" >
                     <tr style="color:black;"><td><center><b>No</b></center></td>
                        <td><center><b>Title</b></center></td>
                        <td><center><b>Question Solved</b></center></td>
                        <td><center><b>Right</b></center></td>
                        <td><center><b>Wrong<b></center></td>
                            <td><center><b>Score</b>
                            </center></td></table>
                        </div></body>
</html>